"use client";

import { motion } from "framer-motion";
import { ShieldAlert, Home } from "lucide-react";
import Link from "next/link";
import { useEffect } from "react";

export default function Terminated() {
    // Clear any remaining session data
    useEffect(() => {
        sessionStorage.removeItem("neurosync_session");
    }, []);

    return (
        <div className="min-h-screen bg-[#1a1a1a] flex flex-col items-center justify-center p-8 text-center font-body">
            <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="max-w-md w-full flex flex-col items-center"
            >
                <motion.div
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.2, type: "spring", stiffness: 180 }}
                    className="w-24 h-24 bg-danger/10 text-danger rounded-[2.5rem] flex items-center justify-center border border-danger/30 mb-10 shadow-[0_0_60px_rgba(239,68,68,0.15)]"
                >
                    <ShieldAlert size={48} strokeWidth={1.5} />
                </motion.div>

                <motion.h1
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.35 }}
                    className="text-white text-4xl font-bold mb-5 tracking-tight"
                    style={{ fontFamily: "serif" }}
                >
                    Session Terminated
                </motion.h1>

                <motion.p
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.45 }}
                    className="text-white/50 text-base leading-relaxed mb-4"
                >
                    Your interview session has been ended due to multiple security violations.
                </motion.p>

                <motion.p
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.55 }}
                    className="text-white/30 text-sm leading-relaxed mb-12 max-w-xs"
                >
                    Exiting full-screen mode is not permitted during the assessment. This incident has been recorded and the hiring team will be notified.
                </motion.p>

                <motion.div
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.65 }}
                >
                    <Link
                        href="/portal/login"
                        className="inline-flex items-center gap-3 px-8 py-4 bg-white/10 hover:bg-white/15 border border-white/10 rounded-2xl text-white/70 hover:text-white font-bold text-sm uppercase tracking-widest transition-all"
                    >
                        <Home size={16} /> Back to Login
                    </Link>
                </motion.div>

                <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.8 }}
                    className="mt-14 text-white/15 text-[10px] uppercase tracking-[0.3em] font-bold"
                >
                    Vidya AI &copy; 2025 — All violations are logged.
                </motion.p>
            </motion.div>
        </div>
    );
}
