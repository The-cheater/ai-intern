"use client";

import React, { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, Home } from "lucide-react";
import Link from "next/link";

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export default function ThankYou() {
    const didFireRef = useRef(false);

    useEffect(() => {
        if (didFireRef.current) return;
        didFireRef.current = true;

        // Grab session id, then clear the session immediately — candidate is done
        const raw = sessionStorage.getItem("neurosync_session");
        sessionStorage.removeItem("neurosync_session");

        if (!raw) return;
        const sid = (JSON.parse(raw) as { session_id?: string })?.session_id;
        if (!sid) return;

        // Fire background processing — we do NOT wait for it or poll it
        // The recruiter sees progress in their dashboard
        fetch(`${API}/session/${sid}/process`, { method: "POST" }).catch(() => {});
        fetch(`${API}/session/${sid}/transcribe`, { method: "POST" }).catch(() => {});
    }, []);

    return (
        <div className="min-h-screen bg-[#f5f1eb] flex flex-col items-center justify-center p-8 text-center relative overflow-hidden font-body text-foreground">
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
                <div className="absolute top-[20%] left-[20%] w-[50%] h-[50%] bg-emerald-500/5 blur-[150px] rounded-full" />
                <div className="absolute bottom-[20%] right-[20%] w-[40%] h-[40%] bg-indigo-500/5 blur-[130px] rounded-full" />
            </div>

            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6 }}
                className="max-w-lg w-full relative z-10 flex flex-col items-center"
            >
                <motion.div
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                    className="w-24 h-24 bg-emerald-500/10 text-emerald-500 rounded-[2.5rem] flex items-center justify-center border border-emerald-500/20 mb-10 shadow-[0_0_40px_rgba(34,197,94,0.15)]"
                >
                    <CheckCircle2 size={48} strokeWidth={1.5} />
                </motion.div>

                <motion.h1
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.35 }}
                    className="font-heading text-5xl font-black mb-5 tracking-tighter leading-tight italic"
                >
                    You&apos;re All Done!
                </motion.h1>

                <motion.p
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.45 }}
                    className="text-foreground/55 text-lg italic mb-4 leading-relaxed"
                >
                    Your interview has been submitted successfully.
                </motion.p>

                <motion.p
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.55 }}
                    className="text-foreground/40 text-base mb-12 leading-relaxed max-w-sm"
                >
                    The hiring team will review your answers and be in touch with you about the next steps.
                </motion.p>

                <motion.div
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.65 }}
                >
                    <Link
                        href="/portal/login"
                        className="px-10 py-5 bg-white hover:bg-gray-50 border border-border rounded-2xl inline-flex items-center gap-3 transition-all font-heading font-black text-sm uppercase tracking-widest text-foreground/60 hover:text-foreground shadow-sm"
                    >
                        <Home size={18} /> Exit
                    </Link>
                </motion.div>

                <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.8 }}
                    className="mt-14 text-foreground/20 text-[10px] uppercase tracking-[0.3em] font-black italic"
                >
                    Vidya AI &copy; 2025 &mdash; Your responses are securely stored.
                </motion.p>
            </motion.div>
        </div>
    );
}
