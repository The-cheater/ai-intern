import json
import logging
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import httpx

from .models import AnswerKey, InterviewScript, Question
from .prompts import SYSTEM_PROMPT, build_batch_prompt

logger = logging.getLogger(__name__)

OLLAMA_URL    = os.getenv("OLLAMA_URL", "http://localhost:11434")
DEFAULT_MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5:0.5b")

# ── Hosted API keys (set at least one for fast generation) ──────────────────
GEMINI_API_KEY  = os.getenv("GEMINI_API_KEY", "")
GEMINI_API_KEY2 = os.getenv("GEMINI_API_KEY2", "")
GEMINI_MODEL    = "gemini-2.0-flash"
GEMINI_URL      = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"

# Groq: free tier, ~800 tok/s, OpenAI-compatible.
# Recommended models: "llama-3.3-70b-versatile" (quality) or "qwen-qwq-32b" (Qwen)
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL   = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
GROQ_URL     = "https://api.groq.com/openai/v1/chat/completions"

# Default batch sizes — used when no section_counts are provided
_DEFAULT_BATCHES = [
    ("intro",       3),
    ("technical",   4),
    ("technical",   3),
    ("behavioral",  4),
    ("logical",     4),
]

_BATCH_MAX = 4   # max questions per LLM call


def _build_batches(section_counts: dict) -> list:
    """Build (stage, count) tuples from a section_counts dict, splitting large sections."""
    batches = []
    for stage, total in section_counts.items():
        remaining = max(1, int(total))
        while remaining > 0:
            chunk = min(remaining, _BATCH_MAX)
            batches.append((stage, chunk))
            remaining -= chunk
    return batches


def _strip_fences(text: str) -> str:
    """Remove ```json ... ``` or ``` ... ``` wrappers the model sometimes adds."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _extract_json(text: str) -> dict:
    """Try direct parse; fall back to extracting the first {...} block."""
    text = _strip_fences(text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # find the outermost { ... }
        m = re.search(r"\{.*\}", text, re.DOTALL)
        if m:
            return json.loads(m.group())
        raise ValueError(f"No JSON object found in response: {text[:200]}")


def _default_question(stage: str, idx: int, resume_snippet: str = "", jd_snippet: str = "") -> Question:
    """Fallback question used when a batch fails after retries."""
    context = (resume_snippet or jd_snippet or "the candidate's background")[:80]
    return Question(
        id=f"q{idx}",
        stage=stage,  # type: ignore[arg-type]
        question=f"Tell me about your experience relevant to {context}.",
        time_window_seconds={"intro": 60, "technical": 90, "behavioral": 90, "logical": 60}.get(stage, 75),
        ideal_answer="Describe specific examples with measurable outcomes.",
        answer_key=AnswerKey(
            critical_keywords=["experience", "outcome"],
            ideal_sentiment="confident",
            rubric="1=vague, 5=adequate, 10=specific with outcomes",
        ),
    )


def _call_ollama(
    system: str,
    user: str,
    model: str,
    ollama_url: str,
    retries: int = 3,
) -> dict:
    chat_payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ],
        "stream": False,
        # No "format":"json" — 0.5b model returns 500 with it on longer prompts
        "options": {"temperature": 0.8, "num_predict": 1024},
    }
    # Fallback payload for older Ollama builds that don't support /api/chat
    gen_payload = {
        "model":  model,
        "prompt": f"{system}\n\n{user}",
        "stream": False,
        "options": {"temperature": 0.8, "num_predict": 1024},
    }
    for attempt in range(retries):
        try:
            attempt_start = time.time()
            logger.info(f"[VidyaAI][Generator]     Ollama attempt {attempt + 1}: POST to {ollama_url}/api/chat...")
            with httpx.Client(timeout=120.0) as client:
                r = client.post(f"{ollama_url}/api/chat", json=chat_payload)
                if r.status_code == 404:
                    logger.info(f"[VidyaAI][Generator]     /api/chat returned 404, trying /api/generate...")
                    r = client.post(f"{ollama_url}/api/generate", json=gen_payload)
                r.raise_for_status()
                data = r.json()
                content = data.get("message", {}).get("content") or data.get("response", "")
                result = _extract_json(content)
                elapsed = time.time() - attempt_start
                logger.info(f"[VidyaAI][Generator]     Ollama HTTP completed in {elapsed:.2f}s (attempt {attempt + 1})")
                return result
        except Exception as e:
            elapsed = time.time() - attempt_start
            if attempt < retries - 1:
                logger.warning(f"[VidyaAI][Generator]     Ollama attempt {attempt + 1} failed in {elapsed:.2f}s: {e}, retrying...")
                time.sleep(2 ** attempt)
                continue
            raise RuntimeError(f"Ollama call failed after {retries} attempts: {e}") from e
    raise RuntimeError("Unreachable")


def _call_gemini(system: str, user: str, retries: int = 3, api_key: str = "") -> dict:
    """Call Gemini 2.0 Flash — free tier, ~1-3s per call."""
    key = api_key or GEMINI_API_KEY
    if not key:
        raise RuntimeError("GEMINI_API_KEY not set")
    payload = {
        "system_instruction": {"parts": [{"text": system}]},
        "contents": [{"role": "user", "parts": [{"text": user}]}],
        "generationConfig": {"temperature": 0.8, "maxOutputTokens": 2048},
    }
    for attempt in range(retries):
        try:
            attempt_start = time.time()
            with httpx.Client(timeout=30.0) as client:
                r = client.post(GEMINI_URL, params={"key": key}, json=payload)
                r.raise_for_status()
                content = r.json()["candidates"][0]["content"]["parts"][0]["text"]
                result = _extract_json(content)
                elapsed = time.time() - attempt_start
                logger.info(f"[VidyaAI][Generator]     Gemini HTTP completed in {elapsed:.2f}s (attempt {attempt + 1})")
                return result
        except Exception as e:
            elapsed = time.time() - attempt_start
            if attempt < retries - 1:
                logger.warning(f"[VidyaAI][Generator]     Gemini attempt {attempt + 1} failed in {elapsed:.2f}s: {e}, retrying...")
                time.sleep(2 ** attempt)
                continue
            raise RuntimeError(f"Gemini call failed after {retries} attempts: {e}") from e
    raise RuntimeError("Unreachable")


_GROQ_FALLBACK_MODEL = "llama-3.3-70b-versatile"


def _call_groq(system: str, user: str, retries: int = 3) -> dict:
    """Call Groq API — free tier, ~800 tok/s, OpenAI-compatible.
    Falls back from GROQ_MODEL to llama-3.3-70b-versatile on 400 errors.
    Get a free key at: https://console.groq.com
    """
    if not GROQ_API_KEY:
        raise RuntimeError("GROQ_API_KEY not set")

    # Try the configured model first; on 400 (unsupported/bad model) use the reliable fallback
    models_to_try = [GROQ_MODEL]
    if GROQ_MODEL != _GROQ_FALLBACK_MODEL:
        models_to_try.append(_GROQ_FALLBACK_MODEL)

    last_error: Exception = RuntimeError("Groq: no models tried")
    for model_name in models_to_try:
        payload = {
            "model": model_name,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user",   "content": user},
            ],
            "temperature": 0.8,
            "max_tokens": 2048,
        }
        model_failed = False
        for attempt in range(retries):
            attempt_start = time.time()
            try:
                logger.info(f"[VidyaAI][Generator]     Groq attempt {attempt + 1}: POST to {GROQ_URL} (model: {model_name})...")
                with httpx.Client(timeout=30.0) as client:
                    r = client.post(
                        GROQ_URL,
                        headers={"Authorization": f"Bearer {GROQ_API_KEY}"},
                        json=payload,
                    )
                    if r.status_code == 400:
                        # Model itself is unsupported — skip retries, try next model
                        logger.warning(f"[VidyaAI][Generator]     Groq model {model_name} returned 400 — trying fallback model...")
                        last_error = RuntimeError(f"Groq 400 for model {model_name}")
                        model_failed = True
                        break
                    r.raise_for_status()
                    content = r.json()["choices"][0]["message"]["content"]
                    result = _extract_json(content)
                    elapsed = time.time() - attempt_start
                    logger.info(f"[VidyaAI][Generator]     Groq HTTP completed in {elapsed:.2f}s (model: {model_name}, attempt {attempt + 1})")
                    return result
            except Exception as e:
                elapsed = time.time() - attempt_start
                last_error = e
                if attempt < retries - 1:
                    logger.warning(f"[VidyaAI][Generator]     Groq attempt {attempt + 1} failed in {elapsed:.2f}s: {e}, retrying...")
                    time.sleep(2 ** attempt)
                else:
                    model_failed = True
        if not model_failed:
            break  # shouldn't reach here if return fired, but safety guard

    raise RuntimeError(f"Groq call failed on all models: {last_error}") from last_error


def _call_llm(system: str, user: str, model: str, ollama_url: str) -> dict:
    """Priority: Gemini Flash → Groq → Ollama (local fallback).
    Set GEMINI_API_KEY or GROQ_API_KEY in .env for fast hosted inference.
    """
    call_start = time.time()
    logger.info(f"[VidyaAI][Generator] → LLM call started (Gemini key1→Gemini key2→Groq→Ollama priority)")
    
    if GEMINI_API_KEY:
        try:
            logger.info(f"[VidyaAI][Generator]   Trying Gemini Flash (key1)...")
            result = _call_gemini(system, user, api_key=GEMINI_API_KEY)
            elapsed = time.time() - call_start
            logger.info(f"[VidyaAI][Generator]   ✓ Gemini key1 SUCCESS in {elapsed:.2f}s")
            return result
        except Exception as e:
            elapsed = time.time() - call_start
            logger.warning(f"[VidyaAI][Generator]   ✗ Gemini key1 failed in {elapsed:.2f}s ({e}), trying key2...")

    if GEMINI_API_KEY2:
        try:
            logger.info(f"[VidyaAI][Generator]   Trying Gemini Flash (key2)...")
            result = _call_gemini(system, user, api_key=GEMINI_API_KEY2)
            elapsed = time.time() - call_start
            logger.info(f"[VidyaAI][Generator]   ✓ Gemini key2 SUCCESS in {elapsed:.2f}s")
            return result
        except Exception as e:
            elapsed = time.time() - call_start
            logger.warning(f"[VidyaAI][Generator]   ✗ Gemini key2 failed in {elapsed:.2f}s ({e}), trying Groq...")

    if GROQ_API_KEY:
        try:
            logger.info(f"[VidyaAI][Generator]   Trying Groq...")
            result = _call_groq(system, user)
            elapsed = time.time() - call_start
            logger.info(f"[VidyaAI][Generator]   ✓ Groq SUCCESS in {elapsed:.2f}s")
            return result
        except Exception as e:
            elapsed = time.time() - call_start
            logger.warning(f"[VidyaAI][Generator]   ✗ Groq failed in {elapsed:.2f}s ({e}), falling back to Ollama")
    
    logger.info(f"[VidyaAI][Generator]   Trying Ollama (this may be slow)...")
    result = _call_ollama(system, user, model, ollama_url)
    elapsed = time.time() - call_start
    logger.info(f"[VidyaAI][Generator]   ✓ Ollama SUCCESS in {elapsed:.2f}s")
    return result


_STAGE_ALIASES = {
    "introduction": "intro",
    "opening":      "intro",
    "tech":         "technical",
    "logic":        "logical",
    "logic_reasoning": "logical",
    "reasoning":    "logical",
    "behaviour":    "behavioral",
    "behaviour_based": "behavioral",
    "behavioural":  "behavioral",
    "situational":  "situational",
}


def _normalize_stage(raw_stage: str, fallback: str) -> str:
    """Map model-returned stage strings to valid enum values."""
    s = (raw_stage or "").strip().lower()
    return _STAGE_ALIASES.get(s, s if s in {"intro", "technical", "behavioral", "logical", "situational"} else fallback)


def _coerce_question(raw: dict, stage: str, idx: int) -> Question:
    """Build a Question from raw dict, filling in missing fields with safe defaults."""
    ak_raw = raw.get("answer_key") or {}
    answer_key = AnswerKey(
        critical_keywords=ak_raw.get("critical_keywords") or [],
        ideal_sentiment=ak_raw.get("ideal_sentiment") or "confident",
        rubric=ak_raw.get("rubric") or "1=poor, 5=adequate, 10=excellent",
    )
    raw_stage = _normalize_stage(raw.get("stage") or "", stage)
    return Question(
        id=raw.get("id") or f"q{idx}",
        stage=raw_stage,  # type: ignore[arg-type]
        question=raw.get("question") or raw.get("text") or f"Question {idx}",
        time_window_seconds=int(raw.get("time_window_seconds") or
                                {"intro": 60, "technical": 90, "behavioral": 90, "logical": 60}.get(stage, 75)),
        ideal_answer=raw.get("ideal_answer") or "",
        answer_key=answer_key,
    )


def _process_batch_result(
    data: dict,
    stage: str,
    count: int,
    q_start: int,
    resume_markdown: str,
    job_description: str,
) -> list:
    """Parse one batch result dict into a list of Questions, padding with fallbacks."""
    raws = data.get("questions") or []
    questions = []
    local_idx = q_start
    added = 0
    for raw in raws[:count]:
        if isinstance(raw, dict):
            questions.append(_coerce_question(raw, stage, local_idx))
            local_idx += 1
            added += 1
    for _ in range(count - added):
        questions.append(_default_question(stage, local_idx, resume_markdown, job_description))
        local_idx += 1
    return questions


def generate_questions(
    resume_markdown: str = "",
    job_description: str = "",
    model: str = DEFAULT_MODEL,
    ollama_url: str = OLLAMA_URL,
    section_counts=None,  # Optional[Dict[str, int]]
) -> InterviewScript:
    """Generate interview questions — all batches run in parallel for maximum speed.

    If *section_counts* is provided (e.g. {"intro": 2, "technical": 5, "behavioral": 3}),
    it overrides the default batch configuration.

    Speed tiers (fastest → slowest):
      1. Gemini 2.0 Flash  — set GEMINI_API_KEY (~1-3s/batch, free 1500 req/day)
      2. Groq              — set GROQ_API_KEY  (~0.5-2s/batch, free 14400 req/day)
                             set GROQ_MODEL=qwen-qwq-32b for hosted Qwen
      3. Ollama local      — fallback, slow without GPU
    """
    logger.info("[VidyaAI][Generator] ✓ START question generation")
    logger.info(f"[VidyaAI][Generator]   Resume: {len(resume_markdown)} chars, JD: {len(job_description)} chars")
    logger.info(f"[VidyaAI][Generator]   Using model: {model}, Ollama URL: {ollama_url}")

    batches = _build_batches(section_counts) if section_counts else _DEFAULT_BATCHES
    logger.info(f"[VidyaAI][Generator] ✓ Building {len(batches)} batches: {batches}")

    # Pre-assign q_idx offsets so all batches can be built before any runs
    tasks: list = []  # (batch_index, stage, count, q_start, prompt)
    q_idx = 1
    logger.info("[VidyaAI][Generator] ✓ Building prompts...")
    for i, (stage, count) in enumerate(batches):
        logger.debug(f"[VidyaAI][Generator]   Batch {i}: {stage}x{count} starting at q{q_idx}")
        prompt = build_batch_prompt(
            stage=stage,
            count=count,
            id_start=q_idx,
            resume_snippet=resume_markdown,
            job_snippet=job_description,
        )
        tasks.append((i, stage, count, q_idx, prompt))
        q_idx += count  # advance by expected count (fallbacks fill any gaps)
    logger.info(f"[VidyaAI][Generator] ✓ All prompts built. Total tasks: {len(tasks)}")

    results: dict = {}  # batch_index -> list[Question]

    # Run all batches concurrently — stagger submissions by 0.4s each to avoid
    # Gemini/Groq rate-limit 429s when all batches fire at the exact same moment.
    logger.info(f"[VidyaAI][Generator] ✓ Starting ThreadPoolExecutor with {min(len(tasks), 5)} workers...")
    start_time = time.time()

    def _staggered_call(batch_idx: int, sys_prompt: str, usr_prompt: str, mdl: str, url: str) -> dict:
        if batch_idx > 0:
            time.sleep(batch_idx * 0.4)  # 0s, 0.4s, 0.8s, 1.2s … per batch
        return _call_llm(sys_prompt, usr_prompt, mdl, url)

    with ThreadPoolExecutor(max_workers=min(len(tasks), 5)) as executor:
        logger.info(f"[VidyaAI][Generator] ✓ Submitting {len(tasks)} LLM calls (staggered)...")
        future_map = {
            executor.submit(_staggered_call, i, SYSTEM_PROMPT, prompt, model, ollama_url): (i, stage, count, q_start)
            for i, stage, count, q_start, prompt in tasks
        }
        logger.info(f"[VidyaAI][Generator] ✓ All {len(future_map)} futures submitted. Waiting for results...")
        completed_count = 0
        for future in as_completed(future_map):
            i, stage, count, q_start = future_map[future]
            completed_count += 1
            elapsed = time.time() - start_time
            logger.info(f"[VidyaAI][Generator] ⏳ [{completed_count}/{len(future_map)}] Batch {i} ({stage}x{count}) completed in {elapsed:.1f}s total")
            try:
                data = future.result()
                results[i] = _process_batch_result(data, stage, count, q_start, resume_markdown, job_description)
                logger.info(f"[VidyaAI][Generator]   ✓ Batch {i} processed: {len(results[i])} questions")
            except Exception as e:
                logger.error(f"[VidyaAI][Generator]   ✗ batch {stage}x{count} failed: {e} — using fallbacks")
                results[i] = [
                    _default_question(stage, q_start + j, resume_markdown, job_description)
                    for j in range(count)
                ]

    # Reconstruct in original batch order
    all_questions = []
    for i in range(len(tasks)):
        all_questions.extend(results[i])

    total_time = time.time() - start_time
    logger.info(f"[VidyaAI][Generator] ✓ DONE! Generated {len(all_questions)} questions in {total_time:.1f}s")
    return InterviewScript(
        job_title=None,
        candidate_name=None,
        questions=all_questions,
    )
