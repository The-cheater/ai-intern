"""GazeFollower post-session video processor.

Processes recorded interview videos to extract accurate gaze metrics.
GazeFollower is an appearance-based model (no per-user calibration at inference).

Install: pip install gazefollower
"""

from __future__ import annotations

import os
import tempfile
from typing import Any, Dict, List, Optional, Tuple

# ── Try importing GazeFollower ────────────────────────────────────────────────
_GF_AVAILABLE = False
try:
    from gazefollower import GazeFollower as _GazeFollower
    _GF_AVAILABLE = True
    print("[VidyaAI][GazeFollower] Library loaded OK")
except Exception as _gf_err:
    print(f"[VidyaAI][GazeFollower] Not available ({_gf_err}) — install with: pip install gazefollower")

_gf_instance: Optional[Any] = None


def _get_gf():
    global _gf_instance
    if _GF_AVAILABLE and _gf_instance is None:
        try:
            _gf_instance = _GazeFollower()
            print("[VidyaAI][GazeFollower] Model instance created")
        except Exception as e:
            print(f"[VidyaAI][GazeFollower] Failed to instantiate model: {e}")
    return _gf_instance


def _extract_frames_cv2(video_path: str, every_n: int = 3) -> List[Any]:
    """Extract frames from video using OpenCV."""
    try:
        import cv2
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            print(f"[VidyaAI][GazeFollower] OpenCV cannot open: {video_path}")
            return []
        frames = []
        idx = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            if idx % every_n == 0:
                frames.append(frame)
            idx += 1
        cap.release()
        print(f"[VidyaAI][GazeFollower] Extracted {len(frames)} frames from {os.path.basename(video_path)}")
        return frames
    except Exception as e:
        print(f"[VidyaAI][GazeFollower] Frame extraction failed: {e}")
        return []


def _classify_zone(x: float, y: float, calibration_data: Optional[Dict] = None) -> str:
    """Classify gaze into screen zones using calibration-derived thresholds when available.

    calibration_data keys used:
      red_y_threshold   — normalised y above which gaze is 'red' (default 0.72)
      upper_y_threshold — normalised y below which gaze is 'strategic' (default 0.55)
      lateral_x_margin  — half-width of the strategic center band (default 0.30)
    """
    cal = calibration_data or {}
    red_y       = cal.get("red_y_threshold",   0.72)
    upper_y     = cal.get("upper_y_threshold",  0.55)
    lat_margin  = cal.get("lateral_x_margin",   0.30)

    if y > red_y:
        return "red"         # looking down (notes / phone on desk)
    if y <= upper_y and abs(x - 0.5) <= lat_margin:
        return "strategic"   # upper-centre (thinking / recall)
    return "neutral"


def _detect_robotic_reading(
    gaze_points: List[Tuple[float, float]],
    baseline_variance: float = 0.004,
) -> Dict[str, Any]:
    """Detect systematic left-right scanning patterns typical of reading from notes.

    Thresholds are adaptive: reversal magnitude and y-spread are scaled by
    sqrt(baseline_variance) so the detector does not false-fire on candidates
    who naturally have small gaze excursions.
    """
    if len(gaze_points) < 10:
        return {"detected": False, "confidence": 0.0}

    # Adaptive threshold: minimum meaningful horizontal step scales with gaze range
    reversal_threshold = max(0.03, (baseline_variance ** 0.5) * 1.5)
    y_spread_threshold = max(0.06, (baseline_variance ** 0.5) * 2.0)

    xs = [p[0] for p in gaze_points]
    reversals = 0
    for i in range(2, len(xs)):
        d1 = xs[i-1] - xs[i-2]
        d2 = xs[i]   - xs[i-1]
        if d1 * d2 < 0 and abs(d1) > reversal_threshold and abs(d2) > reversal_threshold:
            reversals += 1

    reversal_rate = reversals / max(len(gaze_points), 1)
    import statistics
    ys = [p[1] for p in gaze_points]
    y_stdev = statistics.stdev(ys) if len(ys) > 1 else 1.0
    # Robotic reading: high reversal rate AND consistent row height
    is_robotic = reversal_rate > 0.15 and y_stdev < y_spread_threshold
    return {
        "detected":       bool(is_robotic),
        "confidence":     round(min(reversal_rate * 5, 1.0), 3),
        "reversal_rate":  round(reversal_rate, 4),
        "y_stdev":        round(y_stdev, 4),
    }


def run_gazefollower_on_video(
    video_path: str,
    session_id: Optional[str] = None,
    calibration_data: Optional[Dict] = None,
) -> Dict[str, Any]:
    """Analyze a recorded interview video with GazeFollower.

    Returns a structured dict with gaze metrics, zone distribution, and cheat flags.
    Falls back to a placeholder if GazeFollower is not installed.
    """
    print(f"[VidyaAI][GazeFollower] Processing video: {os.path.basename(video_path)}, session={session_id}")

    if not os.path.exists(video_path):
        print(f"[VidyaAI][GazeFollower] Video file not found: {video_path}")
        return {"provider": "gazefollower", "status": "missing_video"}

    if not _GF_AVAILABLE:
        print("[VidyaAI][GazeFollower] Not installed — returning placeholder. Run: pip install gazefollower")
        return {
            "provider":   "gazefollower",
            "status":     "not_installed",
            "install":    "pip install gazefollower",
        }

    gf = _get_gf()
    if gf is None:
        return {"provider": "gazefollower", "status": "model_init_failed"}

    frames = _extract_frames_cv2(video_path, every_n=3)
    if not frames:
        return {"provider": "gazefollower", "status": "no_frames"}

    gaze_points: List[Tuple[float, float]] = []
    failed_frames = 0
    offscreen_count = 0   # frames where GazeFollower predicted outside [0,1]

    for frame in frames:
        try:
            result = gf.predict(frame)
            if result is not None:
                h, w = frame.shape[:2]
                raw_gx = float(result[0]) / max(w, 1)
                raw_gy = float(result[1]) / max(h, 1)
                # Track off-screen predictions BEFORE clamping
                if raw_gx < 0.0 or raw_gx > 1.0 or raw_gy < 0.0 or raw_gy > 1.0:
                    offscreen_count += 1
                gx = max(0.0, min(1.0, raw_gx))
                gy = max(0.0, min(1.0, raw_gy))
                gaze_points.append((gx, gy))
        except Exception:
            failed_frames += 1

    print(f"[VidyaAI][GazeFollower] Got {len(gaze_points)} gaze points "
          f"({failed_frames} frames failed, {offscreen_count} off-screen)")

    if not gaze_points:
        return {"provider": "gazefollower", "status": "no_gaze_detected", "failed_frames": failed_frames}

    total_frames = len(gaze_points)
    offscreen_ratio_raw = round(offscreen_count / max(total_frames, 1), 4)

    # Zone distribution — pass calibration thresholds for personalised classification
    zone_counts: Dict[str, int] = {}
    for x, y in gaze_points:
        z = _classify_zone(x, y, calibration_data)
        zone_counts[z] = zone_counts.get(z, 0) + 1
    total = len(gaze_points)
    zone_distribution = {z: round(c / total, 4) for z, c in zone_counts.items()}

    # Robotic reading detection — use calibration baseline variance for adaptive thresholds
    baseline_var = (calibration_data or {}).get("baseline_gaze_variance", 0.004)
    robotic = _detect_robotic_reading(gaze_points, baseline_variance=baseline_var)

    # Cheating detection (9-signal FFT-based)
    cheat_flags: Dict[str, Any] = {"risk_level": "low"}
    try:
        from services.video_analysis.gaze.cheating_detector import detect_cheating
        baseline_var = (calibration_data or {}).get("baseline_gaze_variance", 0.004)
        cheat_flags = detect_cheating(gaze_points, baseline_variance=baseline_var)
        print(f"[VidyaAI][GazeFollower] Cheat detection: risk_level={cheat_flags.get('risk_level')}")
    except Exception as e:
        print(f"[VidyaAI][GazeFollower] Cheat detection failed: {e}")

    result_dict = {
        "provider":            "gazefollower",
        "status":              "ok",
        "gaze_points_count":   len(gaze_points),
        "failed_frames":       failed_frames,
        "zone_distribution":   zone_distribution,
        "robotic_reading":     robotic,
        "cheat_flags":         cheat_flags,
        # offscreen_ratio_raw: fraction of frames where model predicted outside [0,1]
        # (stronger off-screen signal than zone-based "red" alone)
        "offscreen_ratio":     round(zone_distribution.get("red", 0), 4),
        "offscreen_ratio_raw": offscreen_ratio_raw,
    }
    print(f"[VidyaAI][GazeFollower] Result: zones={zone_distribution} robotic={robotic['detected']}")
    return result_dict
