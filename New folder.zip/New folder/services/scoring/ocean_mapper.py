"""
OCEAN Personality Mapper
========================
Maps per-question ResponseScore objects to Big-Five (OCEAN) trait scores,
computes a blended job-fit score (60% semantic + 40% OCEAN role benchmark),
finds top career matches from personality.csv, calls Gemini/Qwen for a role
recommendation, and saves the full report to outputs/.
"""
import csv
import json
import logging
import os
import re
import uuid
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

import httpx
import numpy as np

from services.question_gen.models import InterviewScript
from services.scoring.models import CareerMatch, OceanReport, OceanScores, ResponseScore, TraitSignals

_PERSONALITY_CSV = Path(__file__).resolve().parents[2] / "personality.csv"

# ── Cooperative keyword list (Agreeableness signal) ──────────────────────────
_COOPERATIVE_WORDS = {"we", "team", "together", "support", "helped", "collaborated",
                      "shared", "our", "us", "collectively", "coordinated", "assisted"}

OLLAMA_URL    = os.getenv("OLLAMA_URL",   "http://localhost:11434")
DEFAULT_MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5:0.5b")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL   = "gemini-2.0-flash"
GEMINI_URL     = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"

OUTPUTS_DIR = Path(__file__).resolve().parents[2] / "outputs"


# ── Personality benchmark CSV loader ─────────────────────────────────────────

@lru_cache(maxsize=1)
def _load_benchmarks() -> Tuple[List[str], np.ndarray]:
    """Load personality.csv once. Returns (names, vectors) where vectors is (N, 5) float32.
    Column order in CSV: O, C, E, A, N → stored as [O, C, E, A, N].
    Returns empty structures if CSV is missing or malformed.
    """
    names: List[str] = []
    vectors: List[List[float]] = []
    if not _PERSONALITY_CSV.exists():
        logger.warning(f"[VidyaAI][OceanMapper] personality.csv not found at {_PERSONALITY_CSV} — role matching disabled")
        return names, np.empty((0, 5), dtype=np.float32)
    try:
        with open(_PERSONALITY_CSV, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    o = float(row["O"]); c = float(row["C"]); e = float(row["E"])
                    a = float(row["A"]); n = float(row["N"])
                    names.append(row["career_name"].strip())
                    vectors.append([o, c, e, a, n])
                except (KeyError, ValueError):
                    continue
        logger.info(f"[VidyaAI][OceanMapper] Loaded {len(names)} role benchmarks from personality.csv")
        return names, np.array(vectors, dtype=np.float32)
    except Exception as ex:
        logger.error(f"[VidyaAI][OceanMapper] Failed to load personality.csv: {ex}")
        return [], np.empty((0, 5), dtype=np.float32)


def _tokenise(text: str) -> set:
    """Lowercase word tokens longer than 3 chars, stripping punctuation."""
    return {w for w in re.findall(r"[a-z]+", text.lower()) if len(w) > 3}


def _find_role_benchmark(job_title_or_description: str) -> Optional[Tuple[str, np.ndarray]]:
    """Find the single best-matching role in the benchmark CSV by keyword overlap
    with the job title/description. Returns (role_name, ocean_01_vector) or None.
    """
    names, vectors = _load_benchmarks()
    if not names:
        return None
    query_tokens = _tokenise(job_title_or_description[:300])
    if not query_tokens:
        return None
    best_idx, best_score = -1, 0.0
    for i, name in enumerate(names):
        role_tokens = _tokenise(name)
        if not role_tokens:
            continue
        overlap = len(query_tokens & role_tokens) / len(role_tokens | query_tokens)
        if overlap > best_score:
            best_score = overlap
            best_idx = i
    # Only accept if there's a meaningful keyword overlap (> 0 shared words)
    if best_idx == -1 or best_score == 0.0:
        return None
    return names[best_idx], vectors[best_idx]


def _ocean_to_01(ocean: OceanScores) -> np.ndarray:
    """Convert OceanScores (0-100 scale) to 0-1 numpy array [O, C, E, A, N]."""
    return np.array([
        ocean.openness, ocean.conscientiousness,
        ocean.extraversion, ocean.agreeableness, ocean.neuroticism,
    ], dtype=np.float32) / 100.0


_MAX_OCEAN_DIST = float(np.sqrt(5))  # max Euclidean distance in 5D unit hypercube


def _distance_to_score(dist: float) -> float:
    """Convert Euclidean distance (0 – sqrt(5)) to a match score (0 – 100)."""
    return round(max(0.0, (1.0 - dist / _MAX_OCEAN_DIST) * 100), 1)


def _compute_ocean_role_fit(ocean: OceanScores, benchmark_vec: np.ndarray) -> float:
    """Return 0-100 score: how closely the candidate's OCEAN matches the role benchmark."""
    candidate_vec = _ocean_to_01(ocean)
    dist = float(np.linalg.norm(candidate_vec - benchmark_vec))
    return _distance_to_score(dist)


def _find_top_career_matches(ocean: OceanScores, n: int = 3) -> List[CareerMatch]:
    """Return the top-n roles from personality.csv whose OCEAN profile is closest
    to the candidate's, sorted by descending match score.
    """
    names, vectors = _load_benchmarks()
    if not names:
        return []
    candidate_vec = _ocean_to_01(ocean)
    # Vectorised distance computation over all 2546 rows at once
    dists = np.linalg.norm(vectors - candidate_vec, axis=1)
    top_indices = np.argsort(dists)[:n]
    return [
        CareerMatch(role=names[i], match_score=_distance_to_score(float(dists[i])))
        for i in top_indices
    ]


# ── Trait interpretation thresholds ──────────────────────────────────────────
def _interpret(trait: str, score: float) -> str:
    level = "High" if score >= 65 else "Moderate" if score >= 40 else "Low"
    _LABELS = {
        "openness": {
            "High": "Creative thinker — brings novel ideas and explores problems from multiple angles.",
            "Moderate": "Balanced approach — open to new ideas but prefers proven methods.",
            "Low": "Prefers structure and convention over experimentation.",
        },
        "conscientiousness": {
            "High": "Highly structured, reliable, and detail-oriented.",
            "Moderate": "Generally organised but may lack consistency under pressure.",
            "Low": "Tends toward spontaneity; may struggle with deadlines and detail.",
        },
        "extraversion": {
            "High": "Energetic and expressive communicator; thrives in collaborative settings.",
            "Moderate": "Comfortable in social settings but also values focused solo work.",
            "Low": "Reserved and measured; may need encouragement to speak up.",
        },
        "agreeableness": {
            "High": "Highly cooperative and empathetic — strong team player.",
            "Moderate": "Balances collaboration with assertiveness.",
            "Low": "Competitive or direct; may create friction in team environments.",
        },
        "neuroticism": {
            "High": "Shows signs of stress reactivity — may struggle under interview pressure.",
            "Moderate": "Some anxiety signals present but generally composed.",
            "Low": "Emotionally stable and calm under pressure.",
        },
    }
    return _LABELS[trait][level]


# ── Feature extractors ────────────────────────────────────────────────────────

def _unique_word_ratio(text: str) -> float:
    """Vocabulary richness: unique words / total words."""
    words = text.lower().split()
    if not words:
        return 0.0
    return len(set(words)) / len(words)


def _cooperative_ratio(text: str) -> float:
    """
    Fraction of words that are cooperative keywords (fixed: uses total word
    count, not unique-word-set-intersection-with-itself which was always len(words)).
    Capped at 1.0 with a 3x scale to reward even moderate cooperative language.
    """
    all_words = text.lower().split()
    if not all_words:
        return 0.0
    hits = sum(1 for w in all_words if w in _COOPERATIVE_WORDS)
    return min(1.0, (hits / len(all_words)) * 3)


def _sentence_count(text: str) -> int:
    """Rough sentence count via punctuation."""
    return max(1, len(re.findall(r"[.!?]+", text)))


def _word_count(text: str) -> int:
    return len([w for w in text.split() if len(w) > 1])


def _depth_ratio(text: str) -> float:
    """
    Response depth signal: 0-1.
    Under 40 words = shallow (0.0–0.4), 40-80 = moderate (0.4-0.7), 80+ = deep (0.7-1.0).
    Used to weight how much trust we place in other signals.
    """
    wc = _word_count(text)
    if wc < 20:
        return 0.0
    if wc < 40:
        return 0.2
    if wc < 80:
        return 0.5
    if wc < 150:
        return 0.75
    return 1.0


def _stress_score(score: ResponseScore) -> float:
    """Inverse engagement + negative sentiment = stress signal (0-1)."""
    stress = score.sentiment.neg + (0.3 if score.engagement_flag else 0.0)
    return min(1.0, stress)


# ── Per-question signal extraction ───────────────────────────────────────────

def _extract_signals(
    score: ResponseScore,
    stage: str,
) -> TraitSignals:
    """
    Return a TraitSignals with 0-1 floats for each relevant trait.
    Signals are depth-weighted so shallow responses don't pollute OCEAN scores.
    
    CRITICAL FIX #4: Comprehensive trait signal extraction across all 5 OCEAN dimensions.
    Each stage extracts all relevant traits instead of just 2-3.
    """
    sig = TraitSignals()
    t = score.transcript
    depth = _depth_ratio(t)
    
    # Common features used across stages
    vocab_richness = _unique_word_ratio(t)
    coop_ratio = _cooperative_ratio(t)
    sent_structure = _sentence_count(t)
    
    if stage == "intro":
        # ✓ Extraversion: positive sentiment + engagement + vocabulary richness
        extraversion_val = (score.sentiment.compound + 1) / 2 * (0.7 if not score.engagement_flag else 0.4)
        sig.extraversion.append(round(extraversion_val * depth, 4))
        
        # ✓ Neuroticism: inverse of stress, only trust if depth
        neuroticism_val = (1.0 - _stress_score(score)) * depth
        sig.neuroticism.append(round(neuroticism_val, 4))
        
        # ✓ Extraversion (alternate): sentence count + expressiveness (more sentences = more expressive)
        expressiveness = min(1.0, sent_structure / 5.0)
        sig.extraversion.append(round(expressiveness * depth, 4))
        
        # ✓ Openness: vocabulary diversity + confidence in self-description
        openness_val = vocab_richness * min(1.0, score.semantic_score)
        sig.openness.append(round(openness_val * depth, 4))
        
        # ✓ Agreeableness: cooperative language + positive sentiment balance
        agree_val = (coop_ratio * 0.5 + ((score.sentiment.compound + 1) / 2) * 0.5)
        sig.agreeableness.append(round(agree_val * depth, 4))
        
        # ✓ Conscientiousness: structured, organized response (multiple sentences)
        intro_structure = min(1.0, sent_structure / 4.0) if sent_structure > 0 else 0.2
        sig.conscientiousness.append(round(intro_structure * depth, 4))

    elif stage in ("technical", "logical"):
        # ✓ Conscientiousness: semantic accuracy + structural organization + detail level
        structure_bonus = min(0.2, sent_structure / 10.0)
        conscientiousness_val = min(1.0, score.semantic_score * 0.8 + structure_bonus * 0.2) * depth
        sig.conscientiousness.append(round(conscientiousness_val, 4))
        
        # ✓ Openness: vocabulary richness + conceptual breadth (diverse word usage)
        sig.openness.append(round(vocab_richness * depth, 4))
        
        # ✓ Neuroticism: uncertainty signals (hedging language) + negative sentiment
        uncertainty_words = sum(1 for w in t.lower().split() if w in {"may", "might", "could", "possibly", "perhaps"})
        uncertainty_signal = min(1.0, uncertainty_words / max(len(t.split()), 1) * 10)
        neuroticism_val = (score.sentiment.neg + uncertainty_signal * 0.3) / 1.3  # Normalize
        sig.neuroticism.append(round(neuroticism_val * depth, 4))
        
        # ✓ Conscientiousness (alternate): detail/specificity (concrete examples, metrics)
        has_numbers = any(c.isdigit() for c in t)
        has_examples = any(w in t.lower() for w in {"example", "such as", "for instance", "specifically"})
        detail_signal = (0.5 if has_numbers else 0.0) + (0.5 if has_examples else 0.0)
        sig.conscientiousness.append(round(detail_signal * depth, 4))

    elif stage == "behavioral":
        # ✓ Agreeableness: cooperative keyword presence + team orientation
        sig.agreeableness.append(round(coop_ratio * depth, 4))
        
        # ✓ Neuroticism: stress indicators (negative sentiment, hedging)
        stress_indicators = score.sentiment.neg + (_stress_score(score) * 0.2)
        sig.neuroticism.append(round(stress_indicators * depth, 4))
        
        # ✓ Conscientiousness: use of STAR method (Situation, Task, Action, Result)
        star_keywords = ["situation", "task", "action", "result", "outcome", "challenge", "did", "resulted"]
        star_hits = sum(1 for w in star_keywords if w in t.lower())
        star_completeness = min(1.0, star_hits / 4.0)  # All 4 STAR elements ideal
        sig.conscientiousness.append(round(star_completeness * depth, 4))
        
        # ✓ Openness: diversity of experience + novel approaches mentioned
        openness_val = vocab_richness * 0.5 + (0.5 if "approach" in t.lower() or "method" in t.lower() else 0.0)
        sig.openness.append(round(openness_val * depth, 4))
        
        # ✓ Extraversion: confident language + active voice usage
        passive_voice = sum(1 for phrase in ["was", "were", "been", "is"] if phrase in t.lower())
        active_ratio = 1.0 - min(1.0, passive_voice / max(sent_structure, 1))
        confidence = min(1.0, score.semantic_score * active_ratio)
        sig.extraversion.append(round(confidence * depth, 4))

    elif stage == "situational":
        # ✓ Openness: creative problem-solving signals + diverse approach
        creative_keywords = ["innovative", "creative", "alternative", "approach", "different", "novel"]
        creativity_signal = sum(1 for kw in creative_keywords if kw in t.lower()) / 6.0
        sig.openness.append(round((vocab_richness * 0.5 + creativity_signal * 0.5) * depth, 4))
        
        # ✓ Conscientiousness: structured multi-part response + practical considerations
        practical_keywords = ["consider", "analyze", "evaluate", "trade-off", "impact", "feasible", "realistic"]
        practical_signal = sum(1 for kw in practical_keywords if kw in t.lower()) / 7.0
        structure = min(1.0, sent_structure / 5.0)
        sig.conscientiousness.append(round((structure * 0.5 + practical_signal * 0.5) * score.semantic_score * depth, 4))
        
        # ✓ Agreeableness: stakeholder consideration + team impact
        stakeholder_keywords = ["team", "stakeholder", "customer", "user", "impact", "people", "collaborate"]
        stakeholder_signal = sum(1 for kw in stakeholder_keywords if kw in t.lower()) / 7.0
        sig.agreeableness.append(round((coop_ratio * 0.5 + stakeholder_signal * 0.5) * depth, 4))
        
        # ✓ Neuroticism: risk awareness (hedging language) vs. decisiveness
        risk_keywords = ["might", "could", "may", "risk", "uncertain", "challenge", "difficult"]
        risk_signal = sum(1 for kw in risk_keywords if kw in t.lower()) / 7.0
        # High risk awareness = lower neuroticism (composed problem-solving)
        neuroticism_val = (1.0 - risk_signal) * depth
        sig.neuroticism.append(round(neuroticism_val, 4))
        
        # ✓ Extraversion: decisiveness + confident recommendations
        decisive_keywords = ["will", "should", "must", "clearly", "definitely", "recommend"]
        decisiveness_signal = sum(1 for kw in decisive_keywords if kw in t.lower()) / 6.0
        sig.extraversion.append(round(decisiveness_signal * depth, 4))

    return sig


# ── Weighted aggregation ──────────────────────────────────────────────────────

def _aggregate(signals: List[float]) -> Optional[float]:
    """
    Weighted mean of signal list; later signals get higher weight.
    Returns None when no signals — caller must handle rather than using a fake default.
    """
    if not signals:
        return None
    weights = list(range(1, len(signals) + 1))
    return sum(s * w for s, w in zip(signals, weights)) / sum(weights)


# ── OCEAN confidence ──────────────────────────────────────────────────────────

def _compute_confidence(questions_scored: int) -> str:
    """
    Confidence in the OCEAN profile based on how many questions were actually answered.
    Low  : fewer than 3 scored questions — treat scores with skepticism
    Medium: 3-5 scored questions
    High : 6+ scored questions — reliable profile
    """
    if questions_scored >= 6:
        return "High"
    if questions_scored >= 3:
        return "Medium"
    return "Low"


# ── Job-fit score via SentenceTransformer ────────────────────────────────────

def _compute_job_fit(transcripts: List[str], job_description: str) -> float:
    if not any(t.strip() for t in transcripts):
        return 0.0  # no interview data — cannot compute job fit
    if not job_description.strip():
        return 0.0  # no job description — cannot compute job fit

    combined_transcript = " ".join(t for t in transcripts if t.strip())

    # Primary: SentenceTransformer cosine similarity
    try:
        from services.scoring.response_scorer import _cosine_similarity, _get_model
        model = _get_model()
        embs = model.encode([combined_transcript, job_description], convert_to_numpy=True)
        sim = _cosine_similarity(embs[0], embs[1])
        return round(min(100.0, max(0.0, sim * 100)), 2)
    except Exception as e:
        logger.warning(f"[VidyaAI][OceanMapper] SentenceTransformer unavailable ({e}) — keyword fallback for job fit")

    # Fallback: keyword overlap (words > 4 chars to skip stop words)
    t_words = set(combined_transcript.lower().split())
    j_words = {w for w in job_description.lower().split() if len(w) > 4}
    if not j_words:
        return 0.0
    overlap = len(t_words & j_words) / len(j_words)
    return round(min(100.0, overlap * 100), 2)


# ── Qwen role recommendation ─────────────────────────────────────────────────

def _get_role_recommendation(
    ocean: OceanScores,
    job_description: str,
    job_fit_score: float,
    confidence: str,
    model: str = DEFAULT_MODEL,
    ollama_url: str = OLLAMA_URL,
) -> str:
    jd_snippet = job_description[:500] if job_description else "Not provided."
    confidence_note = "" if confidence == "High" else f" (Note: confidence is {confidence} — based on limited response data.)"
    prompt = (
        f"OCEAN personality scores (0-100 scale): "
        f"Openness={ocean.openness:.1f}, Conscientiousness={ocean.conscientiousness:.1f}, "
        f"Extraversion={ocean.extraversion:.1f}, Agreeableness={ocean.agreeableness:.1f}, "
        f"Neuroticism={ocean.neuroticism:.1f}. "
        f"Job Fit Score: {job_fit_score:.1f}/100.{confidence_note} "
        f"Role context: {jd_snippet}\n\n"
        "Write exactly 2 sentences as a talent assessor: "
        "(1) Whether this candidate fits the role and the primary reason. "
        "(2) Their single strongest and single weakest personality trait and how each impacts performance."
    )
    system_msg = "You are a concise talent assessment AI. Output plain text only, no JSON, no bullet points."

    # Try Gemini Flash first
    if GEMINI_API_KEY:
        try:
            gemini_payload = {
                "system_instruction": {"parts": [{"text": system_msg}]},
                "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                "generationConfig": {"temperature": 0.4, "maxOutputTokens": 256},
            }
            with httpx.Client(timeout=30.0) as client:
                r = client.post(GEMINI_URL, params={"key": GEMINI_API_KEY}, json=gemini_payload)
                r.raise_for_status()
                return r.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
        except Exception as e:
            logger.warning(f"[VidyaAI][OceanMapper] Gemini recommendation failed ({e}), trying Ollama")

    # Try Ollama /api/chat
    chat_payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_msg},
            {"role": "user",   "content": prompt},
        ],
        "stream": False,
        "options": {"temperature": 0.4, "num_predict": 256},
    }
    try:
        with httpx.Client(timeout=60.0) as client:
            resp = client.post(f"{ollama_url}/api/chat", json=chat_payload)
            if resp.status_code == 200:
                return resp.json()["message"]["content"].strip()
            raise RuntimeError(f"HTTP {resp.status_code}")
    except Exception:
        pass

    # Fall back to Ollama /api/generate
    try:
        gen_payload = {
            "model":  model,
            "prompt": f"{system_msg}\n\n{prompt}",
            "stream": False,
            "options": {"temperature": 0.4, "num_predict": 256},
        }
        with httpx.Client(timeout=60.0) as client:
            resp = client.post(f"{ollama_url}/api/generate", json=gen_payload)
            resp.raise_for_status()
            return resp.json()["response"].strip()
    except Exception as e:
        return (
            f"Job fit score of {job_fit_score:.1f}/100 indicates "
            f"{'a strong' if job_fit_score >= 65 else 'a moderate' if job_fit_score >= 45 else 'a limited'} "
            f"match for this role. Assessment based on OCEAN profile — "
            f"O={ocean.openness:.0f}, C={ocean.conscientiousness:.0f}, "
            f"E={ocean.extraversion:.0f}, A={ocean.agreeableness:.0f}, N={ocean.neuroticism:.0f}."
        )


# ── Success prediction ────────────────────────────────────────────────────────

def _predict_success(ocean: OceanScores, job_fit_score: float) -> str:
    """
    Stricter thresholds than before.
    High   : job_fit >= 70 AND ocean_balance >= 60
    Medium : job_fit >= 55 OR ocean_balance >= 50   (raised from 50/45)
    Low    : everything else
    """
    ocean_balance = np.mean([
        ocean.openness, ocean.conscientiousness,
        ocean.extraversion, ocean.agreeableness,
        100 - ocean.neuroticism,  # low neuroticism is good
    ])
    if job_fit_score >= 70 and ocean_balance >= 60:
        return "High"
    if job_fit_score >= 55 or ocean_balance >= 50:
        return "Medium"
    return "Low"


# ── Main public function ──────────────────────────────────────────────────────

def build_ocean_report(
    scores: List[ResponseScore],
    script: InterviewScript,
    job_description: str = "",
    session_id: Optional[str] = None,
    model: str = DEFAULT_MODEL,
    ollama_url: str = OLLAMA_URL,
) -> OceanReport:
    """
    Map ResponseScore list + InterviewScript to a full OceanReport.
    Saves JSON to outputs/session_{id}_ocean_report.json.
    """
    session_id = session_id or str(uuid.uuid4())[:8]

    # Guard: no interview data — return a clear no-data report
    _no_data_msg = "No interview data available — candidate has not completed the interview."
    has_real_data = any(
        s.transcript.strip() and not s.transcript.startswith("[NO RESPONSE")
        for s in scores
    )
    if not has_real_data:
        ocean = OceanScores(
            openness=0.0, conscientiousness=0.0,
            extraversion=0.0, agreeableness=0.0, neuroticism=0.0,
        )
        report = OceanReport(
            session_id=session_id,
            ocean_scores=ocean,
            trait_interpretations={
                t: _no_data_msg
                for t in ["openness", "conscientiousness", "extraversion",
                          "agreeableness", "neuroticism"]
            },
            job_fit_score=0.0,
            semantic_fit_score=0.0,
            ocean_role_fit=None,
            matched_benchmark_role=None,
            career_suggestions=[],
            success_prediction="Low",
            role_recommendation=_no_data_msg,
            questions_scored=0,
            questions_skipped=len(scores),
            ocean_confidence="Low",
        )
        OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
        out_path = OUTPUTS_DIR / f"session_{session_id}_ocean_report.json"
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(report.model_dump(), f, indent=2, ensure_ascii=False)
        return report

    # Build question-id -> stage map
    stage_map = {q.id: q.stage for q in script.questions}

    # Accumulate trait signals
    all_signals = TraitSignals()
    questions_skipped = 0

    for score in scores:
        stage = stage_map.get(score.question_id, "intro")
        if not score.transcript.strip() or score.transcript.startswith("[NO RESPONSE"):
            questions_skipped += 1
            continue
        sig = _extract_signals(score, stage)
        all_signals.openness.extend(sig.openness)
        all_signals.conscientiousness.extend(sig.conscientiousness)
        all_signals.extraversion.extend(sig.extraversion)
        all_signals.agreeableness.extend(sig.agreeableness)
        all_signals.neuroticism.extend(sig.neuroticism)

    questions_scored = len(scores) - questions_skipped

    # Aggregate to 0-100 scores
    # _aggregate returns None when no signals for a trait — use 50 as a neutral
    # centre ONLY when there is real data from OTHER traits (not a fake default)
    def _safe_agg(signals: List[float]) -> float:
        val = _aggregate(signals)
        return round(val * 100, 1) if val is not None else 50.0

    ocean = OceanScores(
        openness=_safe_agg(all_signals.openness),
        conscientiousness=_safe_agg(all_signals.conscientiousness),
        extraversion=_safe_agg(all_signals.extraversion),
        agreeableness=_safe_agg(all_signals.agreeableness),
        neuroticism=_safe_agg(all_signals.neuroticism),
    )

    trait_interpretations = {
        trait: _interpret(trait, getattr(ocean, trait))
        for trait in ["openness", "conscientiousness", "extraversion", "agreeableness", "neuroticism"]
    }

    # Semantic job-fit (transcript ↔ JD text)
    transcripts = [s.transcript for s in scores]
    semantic_fit = _compute_job_fit(transcripts, job_description)

    # OCEAN-based role fit (candidate OCEAN ↔ personality.csv benchmark)
    benchmark = _find_role_benchmark(job_description)
    ocean_role_fit: Optional[float] = None
    matched_benchmark_role: Optional[str] = None
    if benchmark is not None:
        matched_benchmark_role, benchmark_vec = benchmark
        ocean_role_fit = _compute_ocean_role_fit(ocean, benchmark_vec)
        logger.info(f"[VidyaAI][OceanMapper] Matched benchmark role: '{matched_benchmark_role}' → OCEAN fit {ocean_role_fit:.1f}/100")

    # Blended job-fit: 60% semantic + 40% OCEAN role fit (when benchmark available)
    if ocean_role_fit is not None:
        job_fit_score = round(0.6 * semantic_fit + 0.4 * ocean_role_fit, 2)
    else:
        job_fit_score = semantic_fit

    # Top-3 career suggestions from personality.csv
    career_suggestions = _find_top_career_matches(ocean, n=3)

    # OCEAN confidence — tells recruiter how much to trust the profile
    ocean_confidence = _compute_confidence(questions_scored)

    # Success prediction
    success_prediction = _predict_success(ocean, job_fit_score)

    # Role recommendation
    role_recommendation = _get_role_recommendation(
        ocean, job_description, job_fit_score, ocean_confidence,
        model=model, ollama_url=ollama_url,
    )

    report = OceanReport(
        session_id=session_id,
        ocean_scores=ocean,
        trait_interpretations=trait_interpretations,
        job_fit_score=job_fit_score,
        semantic_fit_score=semantic_fit,
        ocean_role_fit=ocean_role_fit,
        matched_benchmark_role=matched_benchmark_role,
        career_suggestions=career_suggestions,
        success_prediction=success_prediction,
        role_recommendation=role_recommendation,
        questions_scored=questions_scored,
        questions_skipped=questions_skipped,
        ocean_confidence=ocean_confidence,
    )

    # Save to outputs/
    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUTPUTS_DIR / f"session_{session_id}_ocean_report.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report.model_dump(), f, indent=2, ensure_ascii=False)

    return report


# ── Terminal report printer ───────────────────────────────────────────────────

def print_ocean_report(report: OceanReport) -> None:
    BAR_WIDTH = 40

    def bar(score: float) -> str:
        filled = int(score / 100 * BAR_WIDTH)
        return "[" + "#" * filled + "-" * (BAR_WIDTH - filled) + f"] {score:.1f}"

    print()
    print("=" * 65)
    print(f"  OCEAN PERSONALITY REPORT  |  Session: {report.session_id}")
    print("=" * 65)
    print(f"  Questions scored   : {report.questions_scored}")
    print(f"  Questions skipped  : {report.questions_skipped}")
    print(f"  Profile confidence : {report.ocean_confidence}")
    print()

    for trait in ["openness", "conscientiousness", "extraversion", "agreeableness", "neuroticism"]:
        score = getattr(report.ocean_scores, trait)
        print(f"  {trait.upper():<20} {bar(score)}")
        print(f"  {'':20} {report.trait_interpretations[trait]}")
        print()

    print("-" * 65)
    print(f"  JOB FIT SCORE       : {report.job_fit_score:.1f} / 100  "
          f"(semantic {report.semantic_fit_score:.1f} × 60%"
          + (f" + OCEAN role {report.ocean_role_fit:.1f} × 40%)" if report.ocean_role_fit is not None else ")"))
    if report.matched_benchmark_role:
        print(f"  MATCHED BENCHMARK   : {report.matched_benchmark_role}")
    print(f"  SUCCESS PREDICTION  : {report.success_prediction}")
    if report.career_suggestions:
        print()
        print("  CAREER SUGGESTIONS (by OCEAN fit):")
        for m in report.career_suggestions:
            print(f"    {m.match_score:5.1f}/100  {m.role}")
    print()
    print("  ROLE RECOMMENDATION:")
    for line in report.role_recommendation.split(". "):
        if line.strip():
            print(f"    {line.strip()}.")
    print()
    print(f"  Report saved to: outputs/session_{report.session_id}_ocean_report.json")
    print("=" * 65)
